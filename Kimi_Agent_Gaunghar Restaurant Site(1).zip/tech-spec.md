# Gaunghar Restaurant — Technical Specification

## Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| `next` | ^15 | Framework (App Router, Image optimization, font loading) |
| `react` | ^19 | UI library |
| `react-dom` | ^19 | React DOM renderer |
| `typescript` | ^5 | Type safety |
| `@types/react` | ^19 | React type definitions |
| `@types/react-dom` | ^19 | React DOM type definitions |
| `tailwindcss` | ^4 | Utility-first CSS |
| `@tailwindcss/postcss` | ^4 | PostCSS integration for Tailwind v4 |
| `framer-motion` | ^12 | React animations (entrance, hero sequence, carousel, form states) |
| `gsap` | ^3.12 | Horizontal scroll pinning (Signature Dishes Gallery) |
| `lucide-react` | ^0.469 | Icon library |

---

## Component Inventory

### Layout (shared)

| Component | Source | Reuse | Notes |
|-----------|--------|-------|-------|
| **Navigation** | Custom | Global | Shows/hides based on scroll position (`scrollY > 400`). Mobile: full-screen overlay menu. |
| **Footer** | Custom | Global | 4-column grid, newsletter signup form in brand column |
| **FloatingActionButtons** | Custom | Global | Two fixed-position circles (Reservation + WhatsApp). Always visible. |
| **BackToTop** | Custom | Global | Appears at `scrollY > 600`. Positioned left of floating buttons. |

### Sections (page-specific, single-use)

| Component | Notes |
|-----------|-------|
| **HeroSection** | Full-screen carousel (3 images, crossfade, auto-advance 5s). Orchestrated entrance animation sequence on load. Scroll indicator with looping dot animation. |
| **FeaturesSection** | 4-column feature card grid. Horizontal scroll with snap on mobile. |
| **AboutSection** | Cream background. Two side-by-side action cards (Reserve, Menu) with image+content layout. |
| **PopularDishesSection** | 3-column dish card grid (6 items). Header with "Full Menu" link. |
| **WhyChooseUsSection** | 4 statistics with animated counters. Star rating fill-in animation. |
| **SignatureDishesGallery** | **GSAP ScrollTrigger pinned horizontal scroll** (desktop only). Converts to vertical stack on mobile. |
| **TestimonialsSection** | Carousel with 3 visible cards, arrow navigation, dot indicators. |
| **PhotoGallerySection** | Bento asymmetric grid (8 images). Click opens lightbox. |
| **ReservationsSection** | Two-column: contact info left, reservation form right. Full validation + success/error states. |
| **ContactSection** | Two-column: Google Map embed + contact info left, contact form right. |

### Reusable Components

| Component | Source | Used By | Notes |
|-----------|--------|---------|-------|
| **DishCard** | Custom | PopularDishesSection | Image + content overlay. Veg/Non-veg badge. |
| **FeatureCard** | Custom | FeaturesSection | Icon + title + description. Border hover effect. |
| **TestimonialCard** | Custom | TestimonialsSection | Quote + author + star rating on cream background. |
| **Lightbox** | Custom | PhotoGallerySection | Full-screen image viewer with prev/next/close. Keyboard navigation (Esc, arrow keys). |
| **Button** (Primary/Secondary/Ghost) | Custom | Global | Three variants. Uppercase label style. |
| **FormInput** | Custom | ReservationsSection, ContactSection | Text, email, tel, date, select, textarea variants. Validation state styling. |
| **SectionHeading** | Custom | Multiple sections | Playfair Display heading with consistent scroll animation pattern. |

### Hooks

| Hook | Purpose |
|------|---------|
| `useScrollTrigger` | Wrapper around Framer Motion's `useInView` with consistent threshold (0.15) and once=true. Returns ref + inView boolean. Drives all section entrance animations. |

---

## Animation Implementation

| Animation | Library | Implementation Approach | Complexity |
|-----------|---------|------------------------|------------|
| Hero entrance sequence | Framer Motion | `motion.div` with staggered delays (400ms–1800ms). Each element has its own `initial/animate` with increasing delay. Lines split into separate animated elements. | 🔒 High |
| Hero carousel crossfade | Framer Motion | `AnimatePresence` with `mode="wait"`. Outgoing image fades out (800ms), incoming fades in. Auto-advance via `useEffect` interval (5s), paused on hover. | Medium |
| Scroll indicator loop | CSS | `@keyframes` — 6px circle translates 40px down over 2s, infinite. `opacity` fade when `scrollY > 100`. | Low |
| Navbar show/hide | Framer Motion | `motion.nav` with `y` and `opacity` animated based on `scrollY > 400`. `transition: { duration: 0.4 }` | Low |
| Mobile menu slide | Framer Motion | `AnimatePresence` + `motion.div` sliding from right. Links stagger in with 80ms delay. | Low |
| **Section scroll-triggered entrances** | Framer Motion | All sections use `motion.div` with `whileInView`. Three variants: default (`translateY(30px)`), heading-only (`translateY(20px)`), image/grid (`translateY(40px)`). Stagger children with `staggerChildren: 0.1–0.15`. | Medium |
| Statistics counter | Framer Motion | `useMotionValue` + `useTransform` + `animate`. Target value animated over 2s with `ease: "easeOut"`. Triggered by `useInView`. Format with 1 decimal for rating. | Medium |
| Star rating fill | Framer Motion | 5 star elements with staggered `scale: 0→1` and `opacity: 0→1`, triggered after counter completes (delay 2200ms). | Low |
| **Signature Dishes horizontal scroll** | GSAP + ScrollTrigger | `ScrollTrigger.create({ pin: true, scrub: true })`. GSAP timeline animates gallery container `translateX` from `0` to `-(totalWidth - viewportWidth)`. Section unpins when last card visible. Desktop only (>1024px). Mobile falls back to vertical stack. | 🔒 High |
| Gallery card scale/fade | GSAP | Part of the same ScrollTrigger scrub timeline. Each card has `scale: 0.95→1` and `opacity: 0.7→1` as it centers. | Medium |
| Testimonial carousel | Framer Motion | `AnimatePresence` with `custom` direction prop. `motion.div` slides via `translateX`. Tracks current index. Arrow clicks advance/retreat. Dots jump to index. | Medium |
| Lightbox open/close | Framer Motion | `AnimatePresence`. Backdrop `opacity: 0→1` (200ms). Image `scale: 0.9→1` + `opacity: 0→1` (300ms). `exit` reverses. Keyboard listeners for Esc and arrow keys. | Medium |
| Floating button tooltips | CSS | `group-hover` Tailwind class. Tooltip positioned left of button, `opacity` + `translateX` transition on hover. | Low |
| Back to top | Framer Motion | `AnimatePresence` for mount/unmount. `motion.button` with `opacity` + `scale`. Click handler calls `window.scrollTo({ top: 0, behavior: 'smooth' })`. | Low |
| Form success/error states | Framer Motion | `AnimatePresence` + `motion.div`. Success/error content replaces form with `opacity: 0→1` + `translateY(10px)`. | Low |
| Feature card hover | CSS | `transition-all duration-300`. `hover:shadow-lg hover:-translate-y-1` via Tailwind. | Low |
| Dish card hover | CSS | `transition-all duration-300`. `hover:shadow-lg hover:-translate-y-1`. | Low |
| Gallery image hover | CSS | `transition-all duration-300`. `hover:scale-[1.03]`. Zoom icon overlay with `opacity: 0→1` on hover. | Low |
| Newsletter button loading | CSS | Spinner icon swap, `disabled` state. | Low |

---

## State & Logic Plan

### Hero Carousel State

```
activeIndex: number (0–2)
isPaused: boolean (true on hover)
```
`useEffect` interval at 5s increments `activeIndex` unless `isPaused`. `AnimatePresence` handles crossfade. Navigation dots and chevrons are presentational — no separate state, derived from `activeIndex`.

### Navbar Visibility

Derive from `scrollY` via `useScroll` (Framer Motion) or native scroll listener. No dedicated state store — boolean computed inline: `const showNav = scrollY > 400`.

### Testimonials Carousel State

```
currentIndex: number (0–4)
```
Arrow clicks: `setCurrentIndex(prev => clamp(prev ± 1, 0, 4))`. Dot clicks: `setCurrentIndex(i)`. Direction tracking (for slide animation direction) via comparing prev/next index.

### Signature Dishes Horizontal Scroll (GSAP)

No React state. Pure GSAP + ScrollTrigger imperative control:
1. `useLayoutEffect` creates ScrollTrigger instance on mount
2. Calculates gallery total width vs. viewport
3. Scrub timeline drives `translateX`
4. Cleanup on unmount kills ScrollTrigger instance
5. Mobile (<1024px): skip GSAP entirely, render vertical stack

### Lightbox State

```
isOpen: boolean
activeImageIndex: number (0–7)
```
Managed in `PhotoGallerySection`. Passed to `Lightbox` component. Gallery click handlers set both values. Lightbox arrow navigation: `clamp(index ± 1, 0, 7)`. Keyboard: `Escape` closes, `ArrowLeft/Right` navigates.

### Form Handling (Reservation + Contact)

No external library needed. Native React form state:
```
formData: Record<string, string>
errors: Record<string, string>
status: 'idle' | 'submitting' | 'success' | 'error'
```
Validation on submit (required fields, email format). `status` transitions drive UI (loading spinner, success message, error banner). No backend — client-side only with simulated success.

### Newsletter Form (Footer)

```
email: string
status: 'idle' | 'submitting' | 'success'
```
Email validation on submit. Success state shows confirmation text.

---

## Other Key Decisions

### No shadcn/ui

The design is highly bespoke with custom card styling, warm Nepali color palette, and specific animation requirements. shadcn primitives would require heavy override. All components built custom with Tailwind.

### GSAP for Horizontal Scroll Only

Framer Motion handles all other animations. GSAP is isolated to the Signature Dishes Gallery section where ScrollTrigger's `pin` + `scrub` behavior is essential. No mixing — GSAP and Framer Motion operate on separate DOM subtrees.

### Google Maps Embed

Simple `<iframe>` embed with Google Maps embed URL for Pink Bridge, Bijuli Bazar, Kathmandu. No Google Maps API key or JS library needed. `loading="lazy"` for performance.

### Image Strategy

All images use Next.js `<Image>` with:
- `priority` on hero background images (above-fold)
- `loading="lazy"` on all other images
- WebP format via Next.js automatic optimization
- Appropriate `sizes` attribute for responsive grid breakpoints
- `placeholder="blur"` where blur Data URL is available

### Fonts via next/font

Playfair Display (400, 400i, 700) and Inter (400, 500, 600) loaded via `next/font/google` for automatic optimization, self-hosting, and elimination of layout shift.
