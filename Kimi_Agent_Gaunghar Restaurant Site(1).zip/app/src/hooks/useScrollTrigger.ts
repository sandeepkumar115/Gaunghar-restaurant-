import { useRef } from "react";
import { useInView } from "framer-motion";

export function useScrollTrigger(threshold = 0.15) {
  const ref = useRef<HTMLDivElement>(null);
  const inView = useInView(ref, { once: true, amount: threshold });
  return { ref, inView };
}
