import { useState } from "react";
import { Facebook, Instagram, MessageCircle, CheckCircle } from "lucide-react";

export default function Footer() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "success">("idle");

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim()) setStatus("success");
  };

  return (
    <footer className="bg-light-gray pt-24 pb-16">
      <div className="max-w-[1280px] mx-auto px-6 lg:px-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10 lg:gap-8">
          {/* Brand */}
          <div>
            <div className="mb-4">
              <span className="font-display text-2xl font-bold text-primary">Gaunghar</span>
              <span className="block text-[10px] uppercase tracking-[0.15em] text-dark/60 font-body">
                Restaurant
              </span>
            </div>
            <p className="text-sm text-dark/60 mb-6">
              Authentic Nepali Taste, Modern Dining Experience
            </p>
            <div className="flex gap-4 mb-8">
              <a href="https://facebook.gaunghar.com" target="_blank" rel="noopener noreferrer" className="text-dark hover:text-primary transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-dark hover:text-primary transition-colors">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-dark hover:text-primary transition-colors">
                <MessageCircle size={20} />
              </a>
            </div>

            {/* Newsletter */}
            <div>
              <h4 className="text-lg font-display text-dark mb-1">Stay Updated</h4>
              <p className="text-sm text-dark/60 mb-3">
                Get the latest news, special offers, and seasonal menu updates.
              </p>
              {status === "success" ? (
                <div className="flex items-center gap-2 text-green-600 text-sm">
                  <CheckCircle size={16} />
                  Thank you for subscribing!
                </div>
              ) : (
                <form onSubmit={handleSubscribe} className="flex gap-2">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email"
                    className="flex-1 text-sm px-3 py-2.5 border border-dark/10 rounded-sm bg-white focus:outline-none focus:border-primary"
                  />
                  <button
                    type="submit"
                    className="bg-primary text-white text-xs uppercase tracking-[0.05em] font-semibold px-4 py-2.5 rounded-sm hover:bg-primary-dark transition-colors"
                  >
                    Subscribe
                  </button>
                </form>
              )}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-display text-dark mb-4">Quick Links</h4>
            <ul className="space-y-3">
              {["Home", "Menu", "About Us", "Reservations", "Contact"].map((link) => (
                <li key={link}>
                  <a
                    href={`#${link.toLowerCase().replace(" ", "-")}`}
                    className="text-sm text-dark/60 hover:text-primary transition-colors"
                  >
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-lg font-display text-dark mb-4">Services</h4>
            <ul className="space-y-3">
              {["Dine-In", "Takeout", "Catering", "Private Events"].map((service) => (
                <li key={service}>
                  <span className="text-sm text-dark/60">{service}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-lg font-display text-dark mb-4">Contact Us</h4>
            <div className="space-y-3 text-sm text-dark/60">
              <p>Pink Bridge, Bijuli Bazar, Kathmandu 44600, Nepal</p>
              <p className="text-primary">+977-XXX-XXXXXXX</p>
              <p className="text-primary">info@gaunghar.com</p>
              <p>Open Daily: 8:00 AM – 10:00 PM</p>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="mt-16 pt-8 border-t border-dark/10 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-sm text-dark/60">
            &copy; 2024 Gaunghar Restaurant. All rights reserved.
          </p>
          <div className="flex gap-6 text-sm text-dark/60">
            <a href="#" className="hover:text-primary transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-primary transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
