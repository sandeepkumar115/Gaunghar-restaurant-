import { Calendar, MessageCircle } from "lucide-react";

export default function FloatingActionButtons() {
  const scrollToReservations = () => {
    document.getElementById("reservations")?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <>
      {/* WhatsApp */}
      <div className="fixed bottom-24 right-6 z-[400] group">
        <div className="absolute right-full mr-3 top-1/2 -translate-y-1/2 bg-dark/80 text-white text-sm px-3 py-1.5 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
          Chat with us
        </div>
        <a
          href="https://wa.me/977XXXXXXXXX"
          target="_blank"
          rel="noopener noreferrer"
          className="w-14 h-14 rounded-full bg-whatsapp text-white flex items-center justify-center shadow-lg hover:scale-105 transition-transform"
        >
          <MessageCircle size={24} />
        </a>
      </div>

      {/* Reserve */}
      <div className="fixed bottom-6 right-6 z-[400] group">
        <div className="absolute right-full mr-3 top-1/2 -translate-y-1/2 bg-dark/80 text-white text-sm px-3 py-1.5 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none">
          Reserve a Table
        </div>
        <button
          onClick={scrollToReservations}
          className="w-14 h-14 rounded-full bg-primary text-white flex items-center justify-center shadow-lg hover:scale-105 transition-transform"
        >
          <Calendar size={24} />
        </button>
      </div>
    </>
  );
}
