import { useRef, useEffect, useState } from "react";
import { ArrowRight } from "lucide-react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

const signatureDishes = [
  {
    name: "Chicken Choila",
    description: "A Newari classic — grilled chicken tossed with mustard oil, fresh ginger, green chili, and traditional spices. Served with crispy beaten rice.",
    price: "NPR 450",
    image: "/assets/dish-choila.jpg",
  },
  {
    name: "Special Kothey Momo",
    description: "Handcrafted dumplings, half-steamed and half-pan-fried to golden perfection. Filled with seasoned chicken and served with our house tomato-sesame chutney.",
    price: "NPR 385",
    image: "/assets/dish-momo.jpg",
  },
  {
    name: "Thakali Khana Set",
    description: "A soul-warming complete meal featuring our slow-cooked dal, seasonal tarkari, tender meat curry, pickle, and rice — all the flavors of Mustang on one plate.",
    price: "NPR 650",
    image: "/assets/dish-thakali.jpg",
  },
  {
    name: "Sekuwa",
    description: "Tender pieces of meat, marinated in a blend of Himalayan herbs and spices, then grilled over charcoal for that irresistible smoky flavor.",
    price: "NPR 550",
    image: "/assets/dish-sekuwa.jpg",
  },
  {
    name: "Newari Khaja Set",
    description: "The ultimate Nepali tasting experience — a beautiful arrangement of beaten rice, choila, black soybean, spicy potato, boiled egg, and traditional pickles.",
    price: "NPR 750",
    image: "/assets/dish-newari.jpg",
  },
  {
    name: "Nepali Spiced Fried Chicken",
    description: "Our signature crispy fried chicken coated in a secret blend of Nepali spices. Golden, crunchy, and bursting with flavor in every bite.",
    price: "NPR 480",
    image: "/assets/dish-fried-chicken.jpg",
  },
];

export default function SignatureDishesGallery() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const checkMobile = () => setIsMobile(window.innerWidth < 1024);
    checkMobile();
    window.addEventListener("resize", checkMobile);
    return () => window.removeEventListener("resize", checkMobile);
  }, []);

  useEffect(() => {
    if (isMobile || !sectionRef.current || !containerRef.current) return;

    const section = sectionRef.current;
    const container = containerRef.current;
    const cards = container.querySelectorAll(".gallery-card");
    const totalWidth = container.scrollWidth - window.innerWidth;

    const ctx = gsap.context(() => {
      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: section,
          pin: true,
          scrub: 1,
          end: () => `+=${totalWidth}`,
        },
      });

      tl.to(container, { x: -totalWidth, ease: "none" });

      cards.forEach((card) => {
        tl.fromTo(
          card,
          { scale: 0.95, opacity: 0.7 },
          { scale: 1, opacity: 1, ease: "power1.inOut" },
          0
        );
      });
    }, section);

    return () => ctx.revert();
  }, [isMobile]);

  if (isMobile) {
    return (
      <section className="py-16 bg-dark">
        <div className="px-6">
          <h2 className="font-display text-3xl text-white mb-8">Signature Dishes</h2>
          <div className="space-y-6">
            {signatureDishes.map((dish) => (
              <div key={dish.name} className="rounded-xl overflow-hidden">
                <div className="relative aspect-video">
                  <img src={dish.image} alt={dish.name} className="w-full h-full object-cover" loading="lazy" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 p-6">
                    <h3 className="font-display text-2xl text-white">{dish.name}</h3>
                    <p className="text-white/80 text-sm mt-2 line-clamp-2">{dish.description}</p>
                    <p className="text-gold font-semibold mt-3">{dish.price}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section ref={sectionRef} className="relative h-screen bg-dark overflow-hidden">
      {/* Header */}
      <div className="absolute top-10 left-12 z-10 flex items-center gap-10">
        <h2 className="font-display text-5xl text-white">Signature Dishes</h2>
        <span className="text-xs uppercase tracking-[0.08em] text-white/70 hover:text-white transition-colors cursor-pointer flex items-center gap-1">
          Full Menu <ArrowRight size={14} />
        </span>
      </div>

      {/* Gallery */}
      <div
        ref={containerRef}
        className="flex items-center h-full pt-24 pb-10 gap-6 pl-12"
        style={{ width: "fit-content" }}
      >
        {signatureDishes.map((dish) => (
          <div
            key={dish.name}
            className="gallery-card relative flex-shrink-0 w-[60vw] max-w-[900px] min-w-[500px] rounded-xl overflow-hidden"
            style={{ height: "calc(100vh - 160px)" }}
          >
            <img
              src={dish.image}
              alt={dish.name}
              className="absolute inset-0 w-full h-full object-cover"
              loading="lazy"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-8">
              <h3 className="font-display text-4xl text-white">{dish.name}</h3>
              <p className="text-white/80 text-base mt-3 max-w-[400px] leading-relaxed">
                {dish.description}
              </p>
              <p className="text-gold font-semibold text-lg mt-5">{dish.price}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
