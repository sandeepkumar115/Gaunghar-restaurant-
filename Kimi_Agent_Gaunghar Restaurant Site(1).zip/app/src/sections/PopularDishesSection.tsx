import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { useScrollTrigger } from "@/hooks/useScrollTrigger";

const dishes = [
  {
    name: "Chicken Choila",
    description: "Grilled chicken marinated in traditional spices, served with beaten rice and fresh ginger garnish.",
    price: "NPR 450",
    image: "/assets/dish-choila.jpg",
    badge: "non-veg",
  },
  {
    name: "Momo",
    description: "Handcrafted dumplings filled with your choice of chicken or vegetables, served with our signature tomato-sesame chutney.",
    price: "NPR 350",
    image: "/assets/dish-momo.jpg",
    badge: "both",
  },
  {
    name: "Thakali Khana Set",
    description: "A complete traditional Thakali meal with steamed rice, lentil soup, seasonal vegetables, and your choice of meat curry.",
    price: "NPR 650",
    image: "/assets/dish-thakali.jpg",
    badge: "non-veg",
  },
  {
    name: "Sekuwa",
    description: "Charcoal-grilled marinated meat skewers, smoky and succulent, served with pickled radish and fresh salad.",
    price: "NPR 550",
    image: "/assets/dish-sekuwa.jpg",
    badge: "non-veg",
  },
  {
    name: "Newari Khaja Set",
    description: "A festive sampler of beaten rice, buffalo meat, black soybean, boiled egg, and spicy potato — a true Newari celebration.",
    price: "NPR 750",
    image: "/assets/dish-newari.jpg",
    badge: "non-veg",
  },
  {
    name: "Spiced Fried Chicken",
    description: "Crispy golden fried chicken with a Nepali spice twist, served with tangy green chili dipping sauce.",
    price: "NPR 480",
    image: "/assets/dish-fried-chicken.jpg",
    badge: "non-veg",
  },
];

const easing = [0.4, 0, 0.2, 1] as const;

export default function PopularDishesSection() {
  const { ref, inView } = useScrollTrigger(0.15);

  return (
    <section id="menu" className="py-24 lg:py-28 bg-white" ref={ref}>
      <div className="max-w-[1280px] mx-auto px-6 lg:px-12">
        {/* Header */}
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={inView ? { y: 0, opacity: 1 } : {}}
          transition={{ duration: 0.5, ease: easing }}
          className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-16"
        >
          <h2 className="font-display text-3xl lg:text-5xl text-dark">Popular Dishes</h2>
          <span className="text-xs uppercase tracking-[0.08em] text-primary font-semibold flex items-center gap-1 cursor-pointer hover:underline">
            Full Menu <ArrowRight size={14} />
          </span>
        </motion.div>

        {/* Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {dishes.map((dish, i) => (
            <motion.div
              key={dish.name}
              initial={{ y: 40, opacity: 0 }}
              animate={inView ? { y: 0, opacity: 1 } : {}}
              transition={{ duration: 0.7, delay: i * 0.1, ease: easing }}
              className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-lg hover:-translate-y-1 transition-all duration-300"
            >
              <div className="relative aspect-[4/3] overflow-hidden">
                <img
                  src={dish.image}
                  alt={dish.name}
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
                {/* Badge */}
                <span
                  className={`absolute top-3 right-3 text-[10px] uppercase tracking-wider font-semibold px-2.5 py-1 rounded-sm ${
                    dish.badge === "veg"
                      ? "bg-cream text-green-700"
                      : dish.badge === "both"
                      ? "bg-cream text-gold"
                      : "bg-cream text-red-700"
                  }`}
                >
                  {dish.badge === "veg" && <span className="inline-block w-1.5 h-1.5 rounded-full bg-green-600 mr-1" />}
                  {dish.badge === "non-veg" && <span className="inline-block w-1.5 h-1.5 rounded-full bg-red-600 mr-1" />}
                  {dish.badge === "both" && <span className="inline-block w-1.5 h-1.5 rounded-full bg-gold mr-1" />}
                  {dish.badge === "both" ? "Veg/Non-Veg" : dish.badge}
                </span>
              </div>
              <div className="p-6">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="font-display text-lg text-dark">{dish.name}</h3>
                  <span className="text-primary font-bold text-lg">{dish.price}</span>
                </div>
                <p className="text-sm text-dark/60 line-clamp-2">{dish.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
