import { motion } from "framer-motion";
import { Calendar, UtensilsCrossed, ArrowRight } from "lucide-react";
import { useScrollTrigger } from "@/hooks/useScrollTrigger";

const easing = [0.4, 0, 0.2, 1] as const;

export default function AboutSection() {
  const { ref, inView } = useScrollTrigger(0.15);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section id="about" className="py-24 lg:py-36 bg-cream" ref={ref}>
      <div className="max-w-[1280px] mx-auto px-6 lg:px-12">
        <motion.h2
          initial={{ y: 30, opacity: 0 }}
          animate={inView ? { y: 0, opacity: 1 } : {}}
          transition={{ duration: 0.6, ease: easing }}
          className="font-display text-4xl lg:text-[64px] text-dark leading-[1.15] max-w-[800px]"
        >
          Welcome to
          <br />
          Gaunghar
        </motion.h2>

        <motion.p
          initial={{ y: 20, opacity: 0 }}
          animate={inView ? { y: 0, opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.15, ease: easing }}
          className="text-dark/60 text-base lg:text-lg leading-relaxed max-w-[640px] mt-10"
        >
          At Gaunghar, we believe that great food is more than just sustenance — it's a
          celebration of culture, tradition, and togetherness. Our name, "Gaunghar," evokes
          the warmth of a village home where every guest is family and every meal is prepared
          with love. Nestled in the vibrant Pink Bridge area of Kathmandu, we bring the
          authentic flavors of Nepal to your plate, from the smoky mountains of the Himalayas
          to the fertile plains of the Terai.
        </motion.p>

        {/* Action Cards */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-16">
          {/* Reserve Card */}
          <motion.div
            initial={{ y: 40, opacity: 0 }}
            animate={inView ? { y: 0, opacity: 1 } : {}}
            transition={{ duration: 0.7, delay: 0.2, ease: easing }}
            onClick={() => scrollTo("reservations")}
            className="flex flex-col sm:flex-row bg-white border border-dark/10 rounded-xl overflow-hidden cursor-pointer hover:shadow-md transition-all duration-300 group"
          >
            <div className="sm:w-[45%] h-48 sm:h-auto">
              <img
                src="/assets/about-interior.jpg"
                alt="Restaurant interior"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="sm:w-[55%] p-8 flex flex-col justify-center">
              <Calendar className="w-6 h-6 text-primary mb-3" strokeWidth={1.5} />
              <span className="text-xs uppercase tracking-[0.08em] text-primary font-semibold mb-2">
                Reserve a Table
              </span>
              <p className="text-sm text-dark/60 mb-4">
                Book your table at Gaunghar for an unforgettable dining experience.
              </p>
              <ArrowRight className="w-5 h-5 text-primary group-hover:translate-x-1 transition-transform" />
            </div>
          </motion.div>

          {/* Menu Card */}
          <motion.div
            initial={{ y: 40, opacity: 0 }}
            animate={inView ? { y: 0, opacity: 1 } : {}}
            transition={{ duration: 0.7, delay: 0.4, ease: easing }}
            onClick={() => scrollTo("menu")}
            className="flex flex-col sm:flex-row bg-white border border-dark/10 rounded-xl overflow-hidden cursor-pointer hover:shadow-md transition-all duration-300 group"
          >
            <div className="sm:w-[45%] h-48 sm:h-auto">
              <img
                src="/assets/about-chef.jpg"
                alt="Our chef"
                className="w-full h-full object-cover"
              />
            </div>
            <div className="sm:w-[55%] p-8 flex flex-col justify-center">
              <UtensilsCrossed className="w-6 h-6 text-primary mb-3" strokeWidth={1.5} />
              <span className="text-xs uppercase tracking-[0.08em] text-primary font-semibold mb-2">
                See Menu & Order
              </span>
              <p className="text-sm text-dark/60 mb-4">
                Browse our curated selection of authentic Nepali dishes.
              </p>
              <ArrowRight className="w-5 h-5 text-primary group-hover:translate-x-1 transition-transform" />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
