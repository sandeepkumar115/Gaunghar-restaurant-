import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Star } from "lucide-react";
import { useScrollTrigger } from "@/hooks/useScrollTrigger";

const easing = [0.4, 0, 0.2, 1] as const;

interface StatProps {
  target: number;
  suffix: string;
  label: string;
  subtext?: string;
  decimals?: number;
  delay: number;
  inView: boolean;
  stars?: boolean;
}

function AnimatedStat({ target, suffix, label, subtext, decimals = 0, delay, inView, stars }: StatProps) {
  const [count, setCount] = useState(0);
  const [showStars, setShowStars] = useState(false);

  useEffect(() => {
    if (!inView) return;
    const duration = 2000;
    const startTime = Date.now();
    const timer = setTimeout(() => {
      const interval = setInterval(() => {
        const elapsed = Date.now() - startTime - delay;
        const progress = Math.min(elapsed / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);
        setCount(eased * target);
        if (progress >= 1) {
          clearInterval(interval);
          if (stars) setTimeout(() => setShowStars(true), 100);
        }
      }, 16);
      return () => clearInterval(interval);
    }, delay);
    return () => clearTimeout(timer);
  }, [inView, target, delay, stars]);

  return (
    <div className="flex flex-col items-center text-center">
      <div className="font-display text-5xl lg:text-6xl font-bold text-primary">
        {decimals > 0 ? count.toFixed(decimals) : Math.floor(count)}
        <span className="text-dark/40 text-4xl lg:text-5xl">{suffix}</span>
      </div>
      <div className="w-10 h-px bg-dark/10 my-4" />
      <p className="text-base text-dark font-body">{label}</p>
      {subtext && <p className="text-sm text-dark/60 mt-1">{subtext}</p>}
      {stars && (
        <div className="flex gap-1 mt-3">
          {[0, 1, 2, 3, 4].map((i) => (
            <motion.div
              key={i}
              initial={{ scale: 0, opacity: 0 }}
              animate={showStars ? { scale: 1, opacity: 1 } : {}}
              transition={{ delay: i * 0.1, duration: 0.3 }}
            >
              <Star size={16} className="text-gold fill-gold" />
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}

export default function WhyChooseUsSection() {
  const { ref, inView } = useScrollTrigger(0.2);

  return (
    <section className="py-24 lg:py-28 bg-cream" ref={ref}>
      <div className="max-w-[1280px] mx-auto px-6 lg:px-12">
        <motion.h2
          initial={{ y: 20, opacity: 0 }}
          animate={inView ? { y: 0, opacity: 1 } : {}}
          transition={{ duration: 0.5, ease: easing }}
          className="font-display text-3xl lg:text-5xl text-dark text-center"
        >
          Why Choose Us
        </motion.h2>

        <motion.p
          initial={{ y: 20, opacity: 0 }}
          animate={inView ? { y: 0, opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.1, ease: easing }}
          className="text-dark/60 text-base lg:text-lg text-center max-w-[600px] mx-auto mt-6 mb-16 leading-relaxed"
        >
          For over a decade, Gaunghar has been Kathmandu&apos;s go-to destination for authentic
          Nepali cuisine. Our commitment to quality, tradition, and exceptional service has
          earned us the trust of thousands of happy diners.
        </motion.p>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
          <AnimatedStat
            target={4.9}
            suffix="/5"
            label="Customer Rating"
            decimals={1}
            delay={0}
            inView={inView}
            stars
          />
          <AnimatedStat
            target={100}
            suffix="%"
            label="Fresh Ingredients"
            subtext="Locally sourced daily"
            delay={200}
            inView={inView}
          />
          <AnimatedStat
            target={15}
            suffix="+"
            label="Years Experience"
            subtext="Master Nepali chefs"
            delay={400}
            inView={inView}
          />
          <AnimatedStat
            target={50}
            suffix="K+"
            label="Happy Customers"
            subtext="And counting"
            delay={600}
            inView={inView}
          />
        </div>
      </div>
    </section>
  );
}
