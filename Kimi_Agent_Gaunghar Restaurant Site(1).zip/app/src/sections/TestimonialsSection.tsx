import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Star, ChevronLeft, ChevronRight, Quote } from "lucide-react";
import { useScrollTrigger } from "@/hooks/useScrollTrigger";

const testimonials = [
  {
    quote: "Gaunghar is hands down the best Nepali restaurant in Kathmandu. The Chicken Choila reminded me of my grandmother's cooking — absolutely authentic and bursting with flavor.",
    author: "Suman Sharma",
    detail: "Local Food Blogger, Kathmandu",
    rating: 5,
  },
  {
    quote: "We celebrated our anniversary here and it was perfect. The Thakali Set was incredible, and the staff made us feel like family. Highly recommend for special occasions!",
    author: "Priya & Rajesh Maharjan",
    detail: "Regular Diners",
    rating: 5,
  },
  {
    quote: "As a tourist, I wanted an authentic Nepali dining experience and Gaunghar delivered beyond my expectations. The Newari Khaja Set was a revelation — so many flavors in one meal!",
    author: "Emma Richardson",
    detail: "Travel Writer, UK",
    rating: 5,
  },
  {
    quote: "The momos here are simply the best in the city. You can taste the freshness in every bite. We come here every weekend with our family — it's become our tradition.",
    author: "Anita Gurung",
    detail: "Kathmandu Resident",
    rating: 5,
  },
  {
    quote: "I'm a chef myself and I can tell when ingredients are fresh and techniques are authentic. Gaunghar nails both. Their sekuwa is masterfully prepared — smoky, tender, perfect.",
    author: "Chef Bikram Thapa",
    detail: "Executive Chef, Hotel Yak & Yeti",
    rating: 5,
  },
];

const easing = [0.4, 0, 0.2, 1] as const;

export default function TestimonialsSection() {
  const { ref, inView } = useScrollTrigger(0.15);
  const [currentIndex, setCurrentIndex] = useState(0);

  const visibleCount = typeof window !== "undefined" && window.innerWidth < 1024 ? 1 : 3;
  const maxIndex = testimonials.length - visibleCount;

  const next = () => setCurrentIndex((p) => Math.min(p + 1, maxIndex));
  const prev = () => setCurrentIndex((p) => Math.max(p - 1, 0));

  return (
    <section className="py-24 lg:py-28 bg-white" ref={ref}>
      <div className="max-w-[1280px] mx-auto px-6 lg:px-12">
        <motion.h2
          initial={{ y: 20, opacity: 0 }}
          animate={inView ? { y: 0, opacity: 1 } : {}}
          transition={{ duration: 0.5, ease: easing }}
          className="font-display text-3xl lg:text-5xl text-dark text-center mb-16"
        >
          What Our Guests Say
        </motion.h2>

        <motion.div
          initial={{ y: 30, opacity: 0 }}
          animate={inView ? { y: 0, opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.2, ease: easing }}
          className="relative"
        >
          {/* Navigation Arrows */}
          <button
            onClick={prev}
            disabled={currentIndex === 0}
            className="absolute -left-4 lg:-left-12 top-1/2 -translate-y-1/2 z-10 w-10 h-10 rounded-full bg-white border border-dark/10 flex items-center justify-center text-dark hover:bg-primary hover:text-white disabled:opacity-30 disabled:hover:bg-white disabled:hover:text-dark transition-colors"
          >
            <ChevronLeft size={20} />
          </button>
          <button
            onClick={next}
            disabled={currentIndex >= maxIndex}
            className="absolute -right-4 lg:-right-12 top-1/2 -translate-y-1/2 z-10 w-10 h-10 rounded-full bg-white border border-dark/10 flex items-center justify-center text-dark hover:bg-primary hover:text-white disabled:opacity-30 disabled:hover:bg-white disabled:hover:text-dark transition-colors"
          >
            <ChevronRight size={20} />
          </button>

          {/* Cards Container */}
          <div className="overflow-hidden">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentIndex}
                initial={{ opacity: 0.7, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0.7, x: -20 }}
                transition={{ duration: 0.4, ease: easing }}
                className="flex gap-6"
              >
                {testimonials.slice(currentIndex, currentIndex + visibleCount).map((t) => (
                  <div
                    key={t.author}
                    className="flex-1 min-w-0 bg-cream rounded-2xl p-8 lg:p-10"
                  >
                    <Quote className="w-8 h-8 text-gold mb-4" strokeWidth={1.5} />
                    <p className="font-display italic text-base lg:text-lg text-dark leading-relaxed mb-6">
                      &ldquo;{t.quote}&rdquo;
                    </p>
                    <div className="flex gap-1 mb-4">
                      {Array.from({ length: t.rating }).map((_, i) => (
                        <Star key={i} size={16} className="text-gold fill-gold" />
                      ))}
                    </div>
                    <p className="text-sm font-semibold text-dark">{t.author}</p>
                    <p className="text-sm text-dark/60">{t.detail}</p>
                  </div>
                ))}
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Dots */}
          <div className="flex justify-center gap-2 mt-8">
            {testimonials.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrentIndex(Math.min(i, maxIndex))}
                className={`rounded-full transition-all ${
                  i === currentIndex ? "w-2.5 h-2.5 bg-primary" : "w-2 h-2 bg-dark/10"
                }`}
              />
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
