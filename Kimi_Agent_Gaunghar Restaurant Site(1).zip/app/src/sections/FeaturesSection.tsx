import { motion } from "framer-motion";
import { UtensilsCrossed, Users, Leaf, Award } from "lucide-react";
import { useScrollTrigger } from "@/hooks/useScrollTrigger";

const features = [
  {
    icon: UtensilsCrossed,
    title: "Authentic Nepali Cuisine",
    description:
      "Traditional recipes passed down through generations, prepared with authentic spices and techniques that capture the true essence of Nepali flavors.",
  },
  {
    icon: Users,
    title: "Family Friendly",
    description:
      "A warm, welcoming atmosphere perfect for family gatherings, celebrations, and intimate dinners. Spacious seating for groups of all sizes.",
  },
  {
    icon: Leaf,
    title: "Fresh Local Ingredients",
    description:
      "We source the freshest produce, meats, and spices from local Kathmandu markets daily, ensuring every dish bursts with natural flavor.",
  },
  {
    icon: Award,
    title: "Premium Dining",
    description:
      "An elevated dining experience combining traditional Nepali hospitality with modern presentation and impeccable service standards.",
  },
];

export default function FeaturesSection() {
  const { ref, inView } = useScrollTrigger(0.15);

  return (
    <section className="py-24 lg:py-28 bg-white" ref={ref}>
      <div className="max-w-[1280px] mx-auto px-6 lg:px-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, i) => (
            <motion.div
              key={feature.title}
              initial={{ y: 40, opacity: 0 }}
              animate={inView ? { y: 0, opacity: 1 } : {}}
              transition={{ duration: 0.7, delay: i * 0.15, ease: [0.4, 0, 0.2, 1] }}
              className="bg-white border border-dark/10 rounded-xl p-10 text-center hover:border-primary/30 hover:shadow-sm transition-all duration-300"
            >
              <feature.icon className="w-12 h-12 text-primary mx-auto mb-5" strokeWidth={1.5} />
              <h3 className="font-display text-xl lg:text-[22px] text-dark mb-3">{feature.title}</h3>
              <p className="text-dark/60 text-sm leading-relaxed">{feature.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
