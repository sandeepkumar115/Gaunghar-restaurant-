import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Clock, MapPin, Phone, CheckCircle, AlertCircle } from "lucide-react";
import { useScrollTrigger } from "@/hooks/useScrollTrigger";

const timeSlots = [
  "8:00 AM", "8:30 AM", "9:00 AM", "9:30 AM", "10:00 AM", "10:30 AM",
  "11:00 AM", "11:30 AM", "12:00 PM", "12:30 PM", "1:00 PM", "1:30 PM",
  "2:00 PM", "2:30 PM", "3:00 PM", "3:30 PM", "4:00 PM", "4:30 PM",
  "5:00 PM", "5:30 PM", "6:00 PM", "6:30 PM", "7:00 PM", "7:30 PM",
  "8:00 PM", "8:30 PM", "9:00 PM",
];

const guestOptions = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10+"];

const easing = [0.4, 0, 0.2, 1] as const;

export default function ReservationsSection() {
  const { ref, inView } = useScrollTrigger(0.15);
  const [formData, setFormData] = useState({
    name: "", phone: "", email: "", date: "", time: "", guests: "", requests: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [status, setStatus] = useState<"idle" | "submitting" | "success" | "error">("idle");

  const validate = () => {
    const newErrors: Record<string, string> = {};
    if (!formData.name.trim()) newErrors.name = "Name is required";
    if (!formData.phone.trim()) newErrors.phone = "Phone is required";
    if (!formData.date) newErrors.date = "Date is required";
    if (!formData.time) newErrors.time = "Time is required";
    if (!formData.guests) newErrors.guests = "Guests is required";
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = "Invalid email";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setStatus("submitting");
    setTimeout(() => setStatus("success"), 1500);
  };

  const handleChange = (field: string, value: string) => {
    setFormData((p) => ({ ...p, [field]: value }));
    if (errors[field]) setErrors((p) => ({ ...p, [field]: "" }));
  };

  const inputClass = (field: string) =>
    `w-full px-4 py-3.5 border rounded-sm text-[15px] font-body bg-white focus:outline-none transition-colors ${
      errors[field] ? "border-red-500" : "border-dark/10 focus:border-primary focus:shadow-sm"
    }`;

  return (
    <section id="reservations" className="py-24 lg:py-28 bg-white" ref={ref}>
      <div className="max-w-[1280px] mx-auto px-6 lg:px-12">
        <motion.h2
          initial={{ y: 20, opacity: 0 }}
          animate={inView ? { y: 0, opacity: 1 } : {}}
          transition={{ duration: 0.5, ease: easing }}
          className="font-display text-3xl lg:text-5xl text-dark mb-16"
        >
          Reserve a Table
        </motion.h2>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-12 lg:gap-16">
          {/* Left Column - Info */}
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={inView ? { y: 0, opacity: 1 } : {}}
            transition={{ duration: 0.6, delay: 0, ease: easing }}
            className="lg:col-span-2 space-y-8"
          >
            <div className="flex gap-4">
              <Clock className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
              <div>
                <span className="text-xs uppercase tracking-[0.08em] font-semibold text-dark block mb-1">
                  Opening Hours
                </span>
                <p className="text-sm text-dark/60">Opens: 8:00 AM</p>
                <p className="text-sm text-dark/60">Closes: 10:00 PM</p>
              </div>
            </div>

            <div className="flex gap-4">
              <Clock className="w-5 h-5 text-gold flex-shrink-0 mt-0.5" />
              <div>
                <span className="text-xs uppercase tracking-[0.08em] font-semibold text-dark block mb-1">
                  Takeout Hours
                </span>
                <p className="text-sm text-dark/60">9:00 AM – 5:00 PM</p>
              </div>
            </div>

            <div className="flex gap-4">
              <MapPin className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
              <div>
                <span className="text-xs uppercase tracking-[0.08em] font-semibold text-dark block mb-1">
                  Location
                </span>
                <p className="text-sm text-dark/60">
                  Pink Bridge, Bijuli Bazar, Kathmandu 44600, Nepal
                </p>
              </div>
            </div>

            <div className="flex gap-4">
              <Phone className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
              <div>
                <span className="text-xs uppercase tracking-[0.08em] font-semibold text-dark block mb-1">
                  Phone
                </span>
                <p className="text-sm text-primary">+977-XXX-XXXXXXX</p>
              </div>
            </div>

            <div className="bg-cream p-4 rounded-sm">
              <p className="text-sm text-dark/60 italic">
                For reservations of 10 or more guests, please call us directly for special
                arrangements.
              </p>
            </div>
          </motion.div>

          {/* Right Column - Form */}
          <motion.div
            initial={{ y: 40, opacity: 0 }}
            animate={inView ? { y: 0, opacity: 1 } : {}}
            transition={{ duration: 0.7, delay: 0.2, ease: easing }}
            className="lg:col-span-3"
          >
            <div className="bg-cream rounded-2xl p-8 lg:p-10 shadow-md">
              <AnimatePresence mode="wait">
                {status === "success" ? (
                  <motion.div
                    key="success"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-center py-12"
                  >
                    <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
                    <h3 className="font-display text-2xl text-green-600 mb-3">Reservation Confirmed!</h3>
                    <p className="text-dark">
                      Thank you, {formData.name}. Your table for {formData.guests} has been reserved for{" "}
                      {formData.date} at {formData.time}. We look forward to welcoming you to Gaunghar!
                    </p>
                    <button
                      onClick={() => { setStatus("idle"); setFormData({ name: "", phone: "", email: "", date: "", time: "", guests: "", requests: "" }); }}
                      className="mt-6 text-primary text-sm font-medium hover:underline"
                    >
                      Make Another Reservation
                    </button>
                  </motion.div>
                ) : (
                  <motion.form
                    key="form"
                    initial={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    onSubmit={handleSubmit}
                    className="space-y-5"
                  >
                    {status === "error" && (
                      <div className="flex items-center gap-2 bg-red-50 border-l-2 border-red-500 p-3 rounded-sm">
                        <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0" />
                        <p className="text-sm text-red-600">
                          Something went wrong. Please try again or call us directly.
                        </p>
                      </div>
                    )}

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                      <div>
                        <label className="text-sm font-medium text-dark mb-1.5 block">
                          Full Name <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="text"
                          placeholder="Enter your full name"
                          value={formData.name}
                          onChange={(e) => handleChange("name", e.target.value)}
                          className={inputClass("name")}
                        />
                        {errors.name && <p className="text-xs text-red-500 mt-1">{errors.name}</p>}
                      </div>

                      <div>
                        <label className="text-sm font-medium text-dark mb-1.5 block">
                          Phone Number <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="tel"
                          placeholder="+977-XXXXXXXXXX"
                          value={formData.phone}
                          onChange={(e) => handleChange("phone", e.target.value)}
                          className={inputClass("phone")}
                        />
                        {errors.phone && <p className="text-xs text-red-500 mt-1">{errors.phone}</p>}
                      </div>

                      <div>
                        <label className="text-sm font-medium text-dark mb-1.5 block">
                          Email Address
                        </label>
                        <input
                          type="email"
                          placeholder="your@email.com"
                          value={formData.email}
                          onChange={(e) => handleChange("email", e.target.value)}
                          className={inputClass("email")}
                        />
                        {errors.email && <p className="text-xs text-red-500 mt-1">{errors.email}</p>}
                      </div>

                      <div>
                        <label className="text-sm font-medium text-dark mb-1.5 block">
                          Reservation Date <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="date"
                          min={new Date().toISOString().split("T")[0]}
                          value={formData.date}
                          onChange={(e) => handleChange("date", e.target.value)}
                          className={inputClass("date")}
                        />
                        {errors.date && <p className="text-xs text-red-500 mt-1">{errors.date}</p>}
                      </div>

                      <div>
                        <label className="text-sm font-medium text-dark mb-1.5 block">
                          Reservation Time <span className="text-red-500">*</span>
                        </label>
                        <select
                          value={formData.time}
                          onChange={(e) => handleChange("time", e.target.value)}
                          className={inputClass("time")}
                        >
                          <option value="">Select time</option>
                          {timeSlots.map((t) => (
                            <option key={t} value={t}>{t}</option>
                          ))}
                        </select>
                        {errors.time && <p className="text-xs text-red-500 mt-1">{errors.time}</p>}
                      </div>

                      <div>
                        <label className="text-sm font-medium text-dark mb-1.5 block">
                          Number of Guests <span className="text-red-500">*</span>
                        </label>
                        <select
                          value={formData.guests}
                          onChange={(e) => handleChange("guests", e.target.value)}
                          className={inputClass("guests")}
                        >
                          <option value="">Select guests</option>
                          {guestOptions.map((g) => (
                            <option key={g} value={g}>{g}</option>
                          ))}
                        </select>
                        {errors.guests && <p className="text-xs text-red-500 mt-1">{errors.guests}</p>}
                      </div>
                    </div>

                    <div>
                      <label className="text-sm font-medium text-dark mb-1.5 block">
                        Special Requests
                      </label>
                      <textarea
                        placeholder="Any dietary requirements, special occasions, seating preferences..."
                        value={formData.requests}
                        onChange={(e) => handleChange("requests", e.target.value)}
                        className={`${inputClass("requests")} min-h-[120px] resize-y`}
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={status === "submitting"}
                      className="w-full bg-primary text-white text-xs uppercase tracking-[0.06em] font-semibold py-4 rounded-sm hover:bg-primary-dark transition-colors disabled:opacity-70"
                    >
                      {status === "submitting" ? "Confirming..." : "Confirm Reservation"}
                    </button>
                  </motion.form>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
