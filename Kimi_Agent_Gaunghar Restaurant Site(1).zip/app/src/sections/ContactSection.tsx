import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Clock, MapPin, Phone, Mail, CheckCircle } from "lucide-react";
import { useScrollTrigger } from "@/hooks/useScrollTrigger";

const easing = [0.4, 0, 0.2, 1] as const;

export default function ContactSection() {
  const { ref, inView } = useScrollTrigger(0.15);
  const [formData, setFormData] = useState({ name: "", email: "", phone: "", message: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [status, setStatus] = useState<"idle" | "success">("idle");

  const validate = () => {
    const e: Record<string, string> = {};
    if (!formData.name.trim()) e.name = "Name is required";
    if (!formData.email.trim()) e.email = "Email is required";
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) e.email = "Invalid email";
    if (!formData.message.trim()) e.message = "Message is required";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setStatus("success");
  };

  const inputClass = (field: string) =>
    `w-full px-4 py-3.5 border rounded-sm text-[15px] font-body bg-white focus:outline-none transition-colors ${
      errors[field] ? "border-red-500" : "border-dark/10 focus:border-primary focus:shadow-sm"
    }`;

  return (
    <section id="contact" className="py-24 lg:py-28 bg-light-gray" ref={ref}>
      <div className="max-w-[1280px] mx-auto px-6 lg:px-12">
        <motion.h2
          initial={{ y: 20, opacity: 0 }}
          animate={inView ? { y: 0, opacity: 1 } : {}}
          transition={{ duration: 0.5, ease: easing }}
          className="font-display text-3xl lg:text-5xl text-dark text-center"
        >
          Get in Touch
        </motion.h2>

        <motion.p
          initial={{ y: 20, opacity: 0 }}
          animate={inView ? { y: 0, opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.1, ease: easing }}
          className="text-dark/60 text-base lg:text-lg text-center max-w-[600px] mx-auto mt-6 mb-16"
        >
          Have a question or want to make a special arrangement? We&apos;d love to hear from you.
        </motion.p>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-12">
          {/* Left - Map & Info */}
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={inView ? { y: 0, opacity: 1 } : {}}
            transition={{ duration: 0.6, delay: 0.2, ease: easing }}
          >
            {/* Google Map Embed */}
            <div className="rounded-xl overflow-hidden border border-dark/10 mb-8 h-[300px] lg:h-[400px]">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3532.0!2d85.3240!3d27.7100!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMjfCsDQyJzM2LjAiTiA4NcKwMTknMjYuNCJF!5e0!3m2!1sen!2snp!4v1"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Gaunghar Restaurant Location"
              />
            </div>

            {/* Contact Info Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {[
                { icon: MapPin, text: "Pink Bridge, Bijuli Bazar, Kathmandu 44600, Nepal" },
                { icon: Phone, text: "+977-XXX-XXXXXXX", href: "tel:+977XXXXXXXXX" },
                { icon: Mail, text: "info@gaunghar.com", href: "mailto:info@gaunghar.com" },
                { icon: Clock, text: "Daily: 8:00 AM – 10:00 PM" },
              ].map((item, i) => (
                <motion.div
                  key={i}
                  initial={{ y: 20, opacity: 0 }}
                  animate={inView ? { y: 0, opacity: 1 } : {}}
                  transition={{ duration: 0.5, delay: 0.3 + i * 0.08, ease: easing }}
                  className="flex items-center gap-3"
                >
                  <item.icon className="w-4.5 h-4.5 text-primary flex-shrink-0" size={18} />
                  {item.href ? (
                    <a href={item.href} className="text-sm text-primary hover:underline">{item.text}</a>
                  ) : (
                    <span className="text-sm text-dark">{item.text}</span>
                  )}
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Right - Contact Form */}
          <motion.div
            initial={{ y: 40, opacity: 0 }}
            animate={inView ? { y: 0, opacity: 1 } : {}}
            transition={{ duration: 0.7, delay: 0.3, ease: easing }}
          >
            <div className="bg-white border border-dark/10 rounded-2xl p-8 lg:p-10 shadow-sm">
              <AnimatePresence mode="wait">
                {status === "success" ? (
                  <motion.div
                    key="success"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="text-center py-12"
                  >
                    <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
                    <h3 className="font-display text-2xl text-green-600 mb-3">Message Sent!</h3>
                    <p className="text-dark">We&apos;ll get back to you soon.</p>
                    <button
                      onClick={() => { setStatus("idle"); setFormData({ name: "", email: "", phone: "", message: "" }); }}
                      className="mt-6 text-primary text-sm font-medium hover:underline"
                    >
                      Send Another Message
                    </button>
                  </motion.div>
                ) : (
                  <motion.form
                    key="form"
                    initial={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    onSubmit={handleSubmit}
                    className="space-y-5"
                  >
                    <div>
                      <label className="text-sm font-medium text-dark mb-1.5 block">
                        Your Name <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="text"
                        placeholder="John Doe"
                        value={formData.name}
                        onChange={(e) => {
                          setFormData((p) => ({ ...p, name: e.target.value }));
                          if (errors.name) setErrors((p) => ({ ...p, name: "" }));
                        }}
                        className={inputClass("name")}
                      />
                      {errors.name && <p className="text-xs text-red-500 mt-1">{errors.name}</p>}
                    </div>

                    <div>
                      <label className="text-sm font-medium text-dark mb-1.5 block">
                        Email Address <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="email"
                        placeholder="your@email.com"
                        value={formData.email}
                        onChange={(e) => {
                          setFormData((p) => ({ ...p, email: e.target.value }));
                          if (errors.email) setErrors((p) => ({ ...p, email: "" }));
                        }}
                        className={inputClass("email")}
                      />
                      {errors.email && <p className="text-xs text-red-500 mt-1">{errors.email}</p>}
                    </div>

                    <div>
                      <label className="text-sm font-medium text-dark mb-1.5 block">
                        Phone Number
                      </label>
                      <input
                        type="tel"
                        placeholder="+977-XXXXXXXXXX"
                        value={formData.phone}
                        onChange={(e) => setFormData((p) => ({ ...p, phone: e.target.value }))}
                        className={inputClass("phone")}
                      />
                    </div>

                    <div>
                      <label className="text-sm font-medium text-dark mb-1.5 block">
                        Your Message <span className="text-red-500">*</span>
                      </label>
                      <textarea
                        placeholder="Tell us how we can help..."
                        value={formData.message}
                        onChange={(e) => {
                          setFormData((p) => ({ ...p, message: e.target.value }));
                          if (errors.message) setErrors((p) => ({ ...p, message: "" }));
                        }}
                        className={`${inputClass("message")} min-h-[120px] resize-y`}
                      />
                      {errors.message && <p className="text-xs text-red-500 mt-1">{errors.message}</p>}
                    </div>

                    <button
                      type="submit"
                      className="w-full bg-primary text-white text-xs uppercase tracking-[0.06em] font-semibold py-4 rounded-sm hover:bg-primary-dark transition-colors"
                    >
                      Send Message
                    </button>
                  </motion.form>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
