import { useState } from "react";
import { motion } from "framer-motion";
import { ZoomIn } from "lucide-react";
import { useScrollTrigger } from "@/hooks/useScrollTrigger";
import Lightbox from "@/components/Lightbox";

const images = [
  { src: "/assets/gallery-1.jpg", alt: "Momo preparation" },
  { src: "/assets/gallery-2.jpg", alt: "Traditional brass vessels" },
  { src: "/assets/gallery-3.jpg", alt: "Friends dining together" },
  { src: "/assets/gallery-4.jpg", alt: "Nepali spices" },
  { src: "/assets/gallery-5.jpg", alt: "Restaurant exterior" },
  { src: "/assets/gallery-6.jpg", alt: "Traditional clay oven" },
  { src: "/assets/about-kathmandu.jpg", alt: "Kathmandu street" },
];

const easing = [0.4, 0, 0.2, 1] as const;

export default function PhotoGallerySection() {
  const { ref, inView } = useScrollTrigger(0.15);
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);

  const openLightbox = (index: number) => {
    setActiveIndex(index);
    setLightboxOpen(true);
  };

  return (
    <>
      <section className="py-24 lg:py-28 bg-cream" ref={ref}>
        <div className="max-w-[1280px] mx-auto px-6 lg:px-12">
          <motion.h2
            initial={{ y: 20, opacity: 0 }}
            animate={inView ? { y: 0, opacity: 1 } : {}}
            transition={{ duration: 0.5, ease: easing }}
            className="font-display text-3xl lg:text-5xl text-dark mb-16"
          >
            Gallery
          </motion.h2>

          {/* Bento Grid */}
          <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 lg:gap-6">
            {/* Row 1: Large left, medium right */}
            <motion.div
              initial={{ y: 40, opacity: 0 }}
              animate={inView ? { y: 0, opacity: 1 } : {}}
              transition={{ duration: 0.7, delay: 0, ease: easing }}
              className="col-span-2 lg:col-span-2 relative group cursor-pointer rounded-xl overflow-hidden aspect-[16/10]"
              onClick={() => openLightbox(0)}
            >
              <img src={images[0].src} alt={images[0].alt} className="w-full h-full object-cover" loading="lazy" />
              <div className="absolute inset-0 bg-dark/0 group-hover:bg-dark/30 transition-colors flex items-center justify-center">
                <ZoomIn className="text-white opacity-0 group-hover:opacity-100 transition-opacity" size={32} />
              </div>
            </motion.div>

            <motion.div
              initial={{ y: 40, opacity: 0 }}
              animate={inView ? { y: 0, opacity: 1 } : {}}
              transition={{ duration: 0.7, delay: 0.1, ease: easing }}
              className="col-span-1 relative group cursor-pointer rounded-xl overflow-hidden aspect-[4/5]"
              onClick={() => openLightbox(1)}
            >
              <img src={images[1].src} alt={images[1].alt} className="w-full h-full object-cover" loading="lazy" />
              <div className="absolute inset-0 bg-dark/0 group-hover:bg-dark/30 transition-colors flex items-center justify-center">
                <ZoomIn className="text-white opacity-0 group-hover:opacity-100 transition-opacity" size={32} />
              </div>
            </motion.div>

            {/* Row 2: 3 equal */}
            {[2, 3, 4].map((idx, i) => (
              <motion.div
                key={idx}
                initial={{ y: 40, opacity: 0 }}
                animate={inView ? { y: 0, opacity: 1 } : {}}
                transition={{ duration: 0.7, delay: 0.2 + i * 0.1, ease: easing }}
                className="col-span-1 relative group cursor-pointer rounded-xl overflow-hidden aspect-[4/3]"
                onClick={() => openLightbox(idx)}
              >
                <img src={images[idx].src} alt={images[idx].alt} className="w-full h-full object-cover" loading="lazy" />
                <div className="absolute inset-0 bg-dark/0 group-hover:bg-dark/30 transition-colors flex items-center justify-center">
                  <ZoomIn className="text-white opacity-0 group-hover:opacity-100 transition-opacity" size={32} />
                </div>
              </motion.div>
            ))}

            {/* Row 3: Medium left, Large right */}
            <motion.div
              initial={{ y: 40, opacity: 0 }}
              animate={inView ? { y: 0, opacity: 1 } : {}}
              transition={{ duration: 0.7, delay: 0.5, ease: easing }}
              className="col-span-1 relative group cursor-pointer rounded-xl overflow-hidden aspect-[4/5]"
              onClick={() => openLightbox(5)}
            >
              <img src={images[5].src} alt={images[5].alt} className="w-full h-full object-cover" loading="lazy" />
              <div className="absolute inset-0 bg-dark/0 group-hover:bg-dark/30 transition-colors flex items-center justify-center">
                <ZoomIn className="text-white opacity-0 group-hover:opacity-100 transition-opacity" size={32} />
              </div>
            </motion.div>

            <motion.div
              initial={{ y: 40, opacity: 0 }}
              animate={inView ? { y: 0, opacity: 1 } : {}}
              transition={{ duration: 0.7, delay: 0.6, ease: easing }}
              className="col-span-1 lg:col-span-2 relative group cursor-pointer rounded-xl overflow-hidden aspect-[16/10]"
              onClick={() => openLightbox(6)}
            >
              <img src={images[6].src} alt={images[6].alt} className="w-full h-full object-cover" loading="lazy" />
              <div className="absolute inset-0 bg-dark/0 group-hover:bg-dark/30 transition-colors flex items-center justify-center">
                <ZoomIn className="text-white opacity-0 group-hover:opacity-100 transition-opacity" size={32} />
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      <Lightbox
        images={images.map((i) => i.src)}
        isOpen={lightboxOpen}
        activeIndex={activeIndex}
        onClose={() => setLightboxOpen(false)}
        onPrev={() => setActiveIndex((p) => Math.max(0, p - 1))}
        onNext={() => setActiveIndex((p) => Math.min(images.length - 1, p + 1))}
      />
    </>
  );
}
