import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import FloatingActionButtons from "@/components/FloatingActionButtons";
import BackToTop from "@/components/BackToTop";
import HeroSection from "@/sections/HeroSection";
import FeaturesSection from "@/sections/FeaturesSection";
import AboutSection from "@/sections/AboutSection";
import PopularDishesSection from "@/sections/PopularDishesSection";
import WhyChooseUsSection from "@/sections/WhyChooseUsSection";
import SignatureDishesGallery from "@/sections/SignatureDishesGallery";
import TestimonialsSection from "@/sections/TestimonialsSection";
import PhotoGallerySection from "@/sections/PhotoGallery";
import ReservationsSection from "@/sections/ReservationsSection";
import ContactSection from "@/sections/ContactSection";

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      <Navigation />
      <main>
        <HeroSection />
        <FeaturesSection />
        <AboutSection />
        <PopularDishesSection />
        <WhyChooseUsSection />
        <SignatureDishesGallery />
        <TestimonialsSection />
        <PhotoGallerySection />
        <ReservationsSection />
        <ContactSection />
      </main>
      <Footer />
      <FloatingActionButtons />
      <BackToTop />
    </div>
  );
}
